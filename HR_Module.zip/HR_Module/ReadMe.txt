1. Goto �TheSDK� and run �Register_SDK.bat� as Administrator
2. Goto �TheApp� and run �setup.exe�
3. The app should start automatically after installation 
4. You can also run the app by clicking �HR Module.exe�
5. Note down the IP addresses of the devices by visiting the router�s admin dash > Client List
6. You can find the IP address assigned against the MAC addresses of the devices.
7. You can find the MAC address of the Device by going in the Admin dash of the device and then �info�
